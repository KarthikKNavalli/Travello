from django.shortcuts import render
from .models import Destination

# The . (dot) before models signifies a relative import. Relative imports are used to import modules from the same package or directory. The single dot means that models is in the same directory as the module where this import statement is being written.

# Create your views here.
def index(request):

    # dest1 = Destination()
    # dest1.name = "Bengaluru"
    # dest1.price = 5000
    # dest1.desc = " Banglore is also called as Silicon valley and IT Hub of India"
    # dest1.img = 'destination_1.jpg'
    # dest1.offer = False


    # dest2 = Destination()
    # dest2.name = "Vijayapura"
    # dest2.price = 2000
    # dest2.desc = " Vijayapura is famous for Gol Gumbaz which is biggest dome in the Entire India"
    # dest2.img = 'destination_2.jpg'
    # dest2.offer = False

    # dest3 = Destination()
    # dest3.name = "Hubli"
    # dest3.price = 4000
    # dest3.desc = " Hubli is famous for Railway platform which is worlds largest platform"
    # dest3.img = 'destination_3.jpg'
    # dest3.offer = True

    # dest4 = Destination()
    # dest4.name = "Belgavi"
    # dest4.price = 3000
    # dest4.desc = " Belgavi is famous for well known sweet called as Kunda"

    # dest5 = Destination()
    # dest5.name = "Goa"
    # dest5.price = 4500
    # dest5.desc = "Goa is famous for its Beach life "

    # dest6 = Destination()
    # dest6.name = "Pune"
    # dest6.price = 5000
    # dest6.desc = "Pune is famous for Porshe Cars "

    # dests = [dest1,dest2,dest3]


# Fetch data for us and store in dest
    dests = Destination.objects.all()

    # return render(request, "index.html", {'dest1': dest1,'dest2':dest2,'dest3':dest3,'dest4':dest4,'dest5':dest5,'dest6':dest6})
    return render(request, "index.html", {'dests':dests})