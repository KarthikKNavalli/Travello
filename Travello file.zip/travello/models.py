from django.db import models

# Create your models here.

# To convert class to model for migrating to postgres we need to write like this...
class Destination(models.Model):

    name = models.CharField(max_length=100)
    img = models.ImageField(upload_to='pics')
    desc = models.TextField()
    price = models.IntegerField()
    offer = models.BooleanField(default=False)
    href = models.URLField(max_length=1000)




# These lines inside the class define class attributes. Each attribute is specified with its name followed by a colon : and then its type hint.


