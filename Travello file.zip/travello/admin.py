from django.contrib import admin

# Register the model it will automatically give the page
from .models import Destination

# Register your models here.
# It will create the page for adding details for user or admin in admin page
admin.site.register(Destination)